{ "nilai" : 
    [
        { "nrp": "1273001", "nama": "Zena Vilenia", "nilaiakhir": "89", "kelas": "A" }, 
        { "nrp": "1273008", "nama": "Reagen Natalie", "nilaiakhir": "88", "kelas": "B" }, 
        { "nrp": "0873037", "nama": "Marco Kornelius", "nilaiakhir": "84", "kelas": "A" }, 
        { "nrp": "1273002", "nama": "Louis Jupiter", "nilaiakhir": "84", "kelas": "A" }, 
        { "nrp": "1273009", "nama": "Welly Candra", "nilaiakhir": "84", "kelas": "B" }, 
        { "nrp": "1273010", "nama": "Ingrid Listiyani", "nilaiakhir": "83", "kelas": "B" }, 
        { "nrp": "1173029", "nama": "Prima Baraq", "nilaiakhir": "83", "kelas": "B" }, 
        { "nrp": "0873063", "nama": "Wilfandi Aser", "nilaiakhir": "82", "kelas": "B" }, 
        { "nrp": "1273005", "nama": "Tiffani", "nilaiakhir": "81", "kelas": "A" }, 
        { "nrp": "1273011", "nama": "Florrentia Steffani", "nilaiakhir": "81", "kelas": "B" }, 
        { "nrp": "1273003", "nama": "Yogi Prawiradidja", "nilaiakhir": "81", "kelas": "A" }, 
        { "nrp": "1073044", "nama": "Anthony Harun", "nilaiakhir": "81", "kelas": "B" }, 
        { "nrp": "1273006", "nama": "Lucky Aditya", "nilaiakhir": "80", "kelas": "A" }, 
        { "nrp": "1273004", "nama": "Mulyadi", "nilaiakhir": "80", "kelas": "A" }
    ]
}